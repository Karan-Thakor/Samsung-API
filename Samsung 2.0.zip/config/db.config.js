
module.exports = {
    url: "mongodb+srv://infinate2:WBOnz3pJLAtUT6iH@cluster0.a7xco9a.mongodb.net/Samsung"
  };