const md5 = require("md5");
const db = require("../models");
const User = db.user;




exports.register = async(req, res) => {
    let body = req.body;
    let success = false;
    body.password = md5(req.body.password);
   await User.findOne({email: req.body.email}).lean().then(async(data) =>{
    if(data===null){
        let user = new User(body);
        let result = await user.save();
        
        result = result.toObject(); 
        res.send(result);
    }else{
        return res.json({success, errors:"email already exists"})
    }
})
    
}

exports.login = async(req, res) =>{
    
    let user = await User.findOne({email:req.body.email, password:md5(req.body.password)})
    res.send(user)
}
