
module.exports = {
    url: "mongodb+srv://infinate:uuTq687sDSwq3EVJ@cluster0.dib4qcx.mongodb.net/Samsung"
  };